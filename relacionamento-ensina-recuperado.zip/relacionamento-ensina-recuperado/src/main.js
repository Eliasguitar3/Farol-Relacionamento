// src/main.js
// Entry point do Vite - carrega CSS e inicializa a aplicação

import './styles/index.css'
import { initApp } from './scripts/app.js'

// Inicializar quando DOM estiver pronto
document.addEventListener('DOMContentLoaded', function() {
  initApp()
})
