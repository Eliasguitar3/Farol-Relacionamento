// src/scripts/app.js
// Sistema Relacionamento Ensina v8.0
// Recuperado da versão publicada - preserva 100% da funcionalidade
// Integração Supabase ativa: bucket "uploads", tabela "arquivos"

import {
  supabase,
  BUCKET_NAME,
  TABLE_NAME,
  uploadFileToSupabase,
  listFileRecords,
  saveFileRecord,
  deleteFileFromBucket,
  deleteFileRecord,
  listFilesByModule
} from '../config/supabase.js'

// Expor supabase globalmente para compatibilidade
window.supabaseClient = supabase
window.SUPABASE_BUCKET = BUCKET_NAME
window.SUPABASE_TABLE = TABLE_NAME

// ==================== CONFIGURATION ====================
const CONFIG = {
    // Admin credentials (in production, use secure backend)
    ADMIN_USER: 'admin_canopus',
    ADMIN_PASS: 'Canopus@2024!',
    // Allowed domain
    ALLOWED_DOMAIN: '@canopus.com.br',
    // Storage keys
    STORAGE_USER: 're_user',
    STORAGE_ADMIN: 're_admin',
    STORAGE_PROGRESS: 're_progress',
    STORAGE_USERS: 're_users_list'
};

// ==================== STATE ====================
let currentUser = null;
let currentRole = null; // 'user' | 'admin'
let userProgress = {};
let allUsers = [];

// ==================== INITIALIZATION ====================
document.addEventListener('DOMContentLoaded', function() {
    loadTheme();
    checkAuthState();
    setupEventListeners();
    setupDragDrop();
});

// ==================== AUTHENTICATION ====================

function switchTab(tab) {
    document.querySelectorAll('.login-tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.login-form').forEach(f => f.classList.remove('active'));
    document.getElementById('tab-' + tab).classList.add('active');
    document.getElementById('form-' + tab).classList.add('active');
    // Clear errors
    hideError('user');
    hideError('admin');
    hideSuccess('user');
    hideSuccess('admin');
}

// Helper para reabilitar botao
function reenableBtn(type) {
    const btn = document.getElementById(type === 'admin' ? 'btnLoginAdmin' : 'btnLoginUser');
    if (btn) {
        btn.disabled = false;
        btn.innerHTML = type === 'admin'
            ? '<i class="fas fa-lock"></i> Acessar painel ADM'
            : '<i class="fas fa-sign-in-alt"></i> Acessar minha trilha';
    }
}

function loginUser() {
    const nameInput = document.getElementById('userNameInput');
    const emailInput = document.getElementById('userEmailInput');
    const name = nameInput.value.trim();
    const email = emailInput.value.trim().toLowerCase();

    hideError('user');
    hideSuccess('user');

    // Validation
    if (!name) {
        showError('user', 'Por favor, digite seu nome completo.');
        nameInput.classList.add('error');
        reenableBtn('user');
        return;
    }
    nameInput.classList.remove('error');

    if (!email) {
        showError('user', 'Por favor, digite seu e-mail corporativo.');
        emailInput.classList.add('error');
        reenableBtn('user');
        return;
    }

    // Domain restriction
    if (!email.endsWith(CONFIG.ALLOWED_DOMAIN)) {
        showError('user', 'Apenas e-mails ' + CONFIG.ALLOWED_DOMAIN + ' são permitidos.');
        emailInput.classList.add('error');
        reenableBtn('user');
        return;
    }
    emailInput.classList.remove('error');

    // Check if email is valid format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        showError('user', 'Por favor, digite um e-mail válido.');
        emailInput.classList.add('error');
        reenableBtn('user');
        return;
    }
    emailInput.classList.remove('error');

    // Simulate loading
    const btn = document.getElementById('btnLoginUser');
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Verificando...';

    setTimeout(() => {
        // Create user session
        currentUser = { name: name, email: email, role: 'user', loginTime: new Date().toISOString() };
        currentRole = 'user';

        // Save to localStorage
        localStorage.setItem(CONFIG.STORAGE_USER, JSON.stringify(currentUser));

        // Initialize progress if new
        const savedProgress = localStorage.getItem(CONFIG.STORAGE_PROGRESS + '_' + email);
        if (savedProgress) {
            userProgress = JSON.parse(savedProgress);
        } else {
            userProgress = {};
        }

        // Register user in global list
        registerUser(name, email);

        showSuccess('user', 'Login realizado com sucesso! Redirecionando...');
        addActivity('login', 'Login realizado', 'Acesso via e-mail corporativo');

        setTimeout(() => {
            hideLoginScreen();
            showApp();
            updateDashboard();
            showNotification('Bem-vindo, ' + name + '!', 'success');
        }, 800);
    }, 800);
}

function loginAdmin() {
    const userInput = document.getElementById('adminUserInput');
    const passInput = document.getElementById('adminPassInput');
    const username = userInput.value.trim();
    const password = passInput.value;

    hideError('admin');
    hideSuccess('admin');

    if (!username) {
        showError('admin', 'Digite o usuário administrador.');
        userInput.classList.add('error');
        reenableBtn('admin');
        return;
    }
    userInput.classList.remove('error');

    if (!password) {
        showError('admin', 'Digite a senha.');
        passInput.classList.add('error');
        reenableBtn('admin');
        return;
    }
    passInput.classList.remove('error');

    // Simulate loading
    const btn = document.getElementById('btnLoginAdmin');
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Autenticando...';

    setTimeout(() => {
        if (username === CONFIG.ADMIN_USER && password === CONFIG.ADMIN_PASS) {
            currentUser = { name: 'Administrador', email: 'admin@canopus.com.br', role: 'admin', loginTime: new Date().toISOString() };
            currentRole = 'admin';

            localStorage.setItem(CONFIG.STORAGE_ADMIN, JSON.stringify(currentUser));

            showSuccess('admin', 'Acesso administrativo concedido!');

            setTimeout(() => {
                hideLoginScreen();
                showApp();
                updateAdminDashboard();
                showNotification('Painel administrativo ativo', 'success');
            }, 800);
        } else {
            showError('admin', 'Usuário ou senha incorretos.');
            passInput.classList.add('error');
            reenableBtn('admin');
        }
    }, 800);
}

function logout() {
    // Clear session
    currentUser = null;
    currentRole = null;
    userProgress = {};

    // Clear localStorage
    localStorage.removeItem(CONFIG.STORAGE_USER);
    localStorage.removeItem(CONFIG.STORAGE_ADMIN);

    // Reset UI
    document.getElementById('loginScreen').classList.remove('hidden');
    document.getElementById('mainContent').style.display = 'none';
    document.getElementById('userInfoPanel').style.display = 'none';
    document.getElementById('adminMenuSection').style.display = 'none';

    // Reset forms
    document.getElementById('userNameInput').value = '';
    document.getElementById('userEmailInput').value = '';
    document.getElementById('adminUserInput').value = '';
    document.getElementById('adminPassInput').value = '';

    // Reset buttons
    document.getElementById('btnLoginUser').disabled = false;
    document.getElementById('btnLoginUser').innerHTML = '<i class="fas fa-sign-in-alt"></i> Acessar minha trilha';
    document.getElementById('btnLoginAdmin').disabled = false;
    document.getElementById('btnLoginAdmin').innerHTML = '<i class="fas fa-lock"></i> Acessar painel ADM';

    // Hide errors
    hideError('user');
    hideError('admin');
    hideSuccess('user');
    hideSuccess('admin');

    // Reset nav
    document.querySelectorAll('.nav-item').forEach(item => item.classList.remove('active'));
    document.querySelector('[data-page="dashboard"]').classList.add('active');

    // Reset pages
    document.querySelectorAll('.page-section').forEach(p => p.classList.remove('active'));
    document.getElementById('page-dashboard').classList.add('active');

    showNotification('Você saiu da plataforma', 'info');
}

function checkAuthState() {
    // Check for existing session
    const savedUser = localStorage.getItem(CONFIG.STORAGE_USER);
    const savedAdmin = localStorage.getItem(CONFIG.STORAGE_ADMIN);

    if (savedAdmin) {
        try {
            const admin = JSON.parse(savedAdmin);
            currentUser = admin;
            currentRole = 'admin';
            hideLoginScreen();
            showApp();
            updateAdminDashboard();
        } catch(e) {
            localStorage.removeItem(CONFIG.STORAGE_ADMIN);
        }
    } else if (savedUser) {
        try {
            const user = JSON.parse(savedUser);
            // Verify domain still valid
            if (user.email && user.email.endsWith(CONFIG.ALLOWED_DOMAIN)) {
                currentUser = user;
                currentRole = 'user';
                const savedProgress = localStorage.getItem(CONFIG.STORAGE_PROGRESS + '_' + user.email);
                if (savedProgress) {
                    userProgress = JSON.parse(savedProgress);
                }
                hideLoginScreen();
                showApp();
                updateDashboard();
            } else {
                localStorage.removeItem(CONFIG.STORAGE_USER);
            }
        } catch(e) {
            localStorage.removeItem(CONFIG.STORAGE_USER);
        }
    }
}

// ==================== UI HELPERS ====================

function hideLoginScreen() {
    document.getElementById('loginScreen').classList.add('hidden');
}

function showApp() {
    document.getElementById('mainContent').style.display = 'block';
    document.getElementById('userInfoPanel').style.display = 'block';
    loadNotifications();
    recordLogin();
    checkAchievements();

    // Update sidebar user info
    if (currentUser) {
        document.getElementById('sidebarUserName').textContent = currentUser.name;
        document.getElementById('sidebarUserEmail').textContent = currentUser.email;
        document.getElementById('dashboardUserName').textContent = currentUser.name;

        const roleEl = document.getElementById('sidebarUserRole');
        if (currentRole === 'admin') {
            roleEl.textContent = 'Administrador';
            roleEl.className = 'user-role admin';
            document.getElementById('adminMenuSection').style.display = 'block';
        } else {
            roleEl.textContent = 'Colaborador';
            roleEl.className = 'user-role user';
            document.getElementById('adminMenuSection').style.display = 'none';
        }
    }
}

function showError(formId, message) {
    const el = document.getElementById('error-' + formId);
    el.querySelector('span').textContent = message;
    el.classList.add('show');
}

function hideError(formId) {
    document.getElementById('error-' + formId).classList.remove('show');
}

function showSuccess(formId, message) {
    const el = document.getElementById('success-' + formId);
    el.querySelector('span').textContent = message;
    el.classList.add('show');
}

function hideSuccess(formId) {
    document.getElementById('success-' + formId).classList.remove('show');
}

// ==================== NAVIGATION ====================

function navigateTo(page) {
    // Route protection - check auth
    if (!currentUser) {
        showNotification('Faça login para acessar esta página', 'error');
        return;
    }

    // Admin route protection
    const adminPages = ['admin-dashboard', 'admin-content', 'admin-users'];
    if (adminPages.includes(page) && currentRole !== 'admin') {
        showNotification('Acesso restrito a administradores', 'error');
        return;
    }

    // Handle generic module pages
    const modulePrefix = 'mod-';
    const isModulePage = page.startsWith(modulePrefix);
    let actualPage = page;
    let moduleId = null;

    if (isModulePage) {
        moduleId = page;
        actualPage = 'module-generic';
        // Load module content dynamically
        loadModuleContent(moduleId);
    }

    // Close mobile sidebar
    document.getElementById('sidebar').classList.remove('open');
    document.querySelector('.overlay').classList.remove('show');

    // Update nav active state
    document.querySelectorAll('.nav-item').forEach(item => {
        if (item.dataset.page === page || item.dataset.page === actualPage) {
            item.classList.add('active');
        } else {
            item.classList.remove('active');
        }
    });

    // Show page
    document.querySelectorAll('.page-section').forEach(section => {
        section.classList.remove('active');
    });
    const targetPage = document.getElementById('page-' + actualPage);
    if (targetPage) {
        targetPage.classList.add('active');
    }

    // Update breadcrumb
    updateBreadcrumb(page);

    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });

    // Page-specific updates
    if (page === 'dashboard') {
        updateDashboard();
    } else if (page === 'admin-dashboard') {
        updateAdminDashboard();
    } else if (page === 'certificados') {
        updateCertificates();
    } else if (page === 'user-profile') {
        updateUserProfilePage();
    } else if (page.startsWith('trilha-')) {
        updateDashboard(); // Refresh trail progress
    }
}

function toggleSubmenu(submenuId, triggerEl) {
    const submenu = document.getElementById(submenuId);
    submenu.classList.toggle('open');
    triggerEl.classList.toggle('expanded');
}

function updateBreadcrumb(page) {
    const names = {
        'dashboard': 'Dashboard',
        'trilhas': 'Trilhas de Aprendizagem',
        'trilha-onboarding': 'Onboarding Geral',
        'trilha-relacionamento': 'Relacionamento',
        'trilha-juridico': 'Jurídico',
        'trilha-compliance': 'Compliance',
        'modulo-1': 'Módulo 1: Atendimento ao Cliente',
        'modulo-2': 'Módulo 2: Comunicação Efetiva',
        'modulo-3': 'Módulo 3: SAC e Ouvidoria',
        'modulo-4': 'Módulo 4: Relacionamento com Clientes',
        'modulo-5': 'Módulo 5: Gestão e Liderança',
        'mod-onboarding-1': 'Boas-vindas',
        'mod-onboarding-2': 'História da Empresa',
        'mod-onboarding-3': 'Cultura e Valores',
        'mod-onboarding-4': 'Estrutura Organizacional',
        'mod-onboarding-5': 'Comunicação Interna',
        'mod-onboarding-6': 'Postura Profissional',
        'mod-onboarding-7': 'Sistemas Utilizados',
        'mod-onboarding-8': 'Jornada do Cliente',
        'mod-onboarding-9': 'Encerramento',
        'mod-rel-1': 'Jornada do Cliente',
        'mod-rel-2': 'Atendimento Humanizado',
        'mod-rel-3': 'Escrita Encantadora',
        'mod-rel-4': 'Comunicação Profissional',
        'mod-rel-5': 'Gestão de Conflitos',
        'mod-rel-6': 'SLA e Prazos',
        'mod-rel-7': 'Fluxos Operacionais',
        'mod-rel-8': 'Sistemas Internos',
        'mod-rel-9': 'Modelos de Resposta',
        'mod-rel-10': 'FAQ Operacional',
        'mod-astec-1': 'Fluxo de Assistência Técnica',
        'mod-astec-2': 'Vistorias',
        'mod-astec-3': 'Garantias',
        'mod-astec-4': 'Chamados',
        'mod-astec-5': 'SLA Técnico',
        'mod-back-1': 'Fluxos Internos',
        'mod-back-2': 'Processos Administrativos',
        'mod-back-3': 'Comunicação entre Áreas',
        'mod-back-4': 'Controles Internos',
        'mod-rec-1': 'Negociação',
        'mod-rec-2': 'Cobrança Humanizada',
        'mod-rec-3': 'Fluxos Financeiros',
        'mod-rec-4': 'Acordos',
        'mod-rec-5': 'Indicadores',
        'mod-jur-1': 'Contratos',
        'mod-jur-2': 'Fluxos Jurídicos',
        'mod-jur-3': 'Comunicação Jurídica',
        'mod-jur-4': 'Padronizações',
        'mod-comp-1': 'Ética Corporativa',
        'mod-comp-2': 'LGPD',
        'mod-comp-3': 'Segurança da Informação',
        'mod-comp-4': 'Conduta Profissional',
        'mod-comp-5': 'Políticas Internas',
        'faq': 'FAQ — Perguntas Frequentes',
        'certificados': 'Certificados',
        'user-profile': 'Meu Perfil',
        'admin-dashboard': 'Painel administrativo',
        'admin-content': 'Gerenciar conteúdo',
        'admin-users': 'Gerenciar usuários'
    };
    document.getElementById('breadcrumbText').textContent = names[page] || 'Dashboard';
}

function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('open');
    document.querySelector('.overlay').classList.toggle('show');
}

// ==================== DASHBOARD & PROGRESS ====================

function updateDashboard() {
    if (!currentUser || currentRole !== 'user') return;

    // All module IDs across all trails
    const allModules = [
        // Legacy modules
        'mod1', 'mod2', 'mod3', 'mod4', 'mod5',
        // Onboarding
        'mod-onboarding-1', 'mod-onboarding-2', 'mod-onboarding-3', 'mod-onboarding-4',
        'mod-onboarding-5', 'mod-onboarding-6', 'mod-onboarding-7', 'mod-onboarding-8', 'mod-onboarding-9',
        // Relacionamento
        'mod-rel-1', 'mod-rel-2', 'mod-rel-3', 'mod-rel-4', 'mod-rel-5',
        'mod-rel-6', 'mod-rel-7', 'mod-rel-8', 'mod-rel-9', 'mod-rel-10',
        // ASTEC
        'mod-astec-1', 'mod-astec-2', 'mod-astec-3', 'mod-astec-4', 'mod-astec-5',
        // Backoffice
        'mod-back-1', 'mod-back-2', 'mod-back-3', 'mod-back-4',
        // Recuperação de Crédito
        'mod-rec-1', 'mod-rec-2', 'mod-rec-3', 'mod-rec-4', 'mod-rec-5',
        // Jurídico
        'mod-jur-1', 'mod-jur-2', 'mod-jur-3', 'mod-jur-4',
        // Compliance
        'mod-comp-1', 'mod-comp-2', 'mod-comp-3', 'mod-comp-4', 'mod-comp-5'
    ];

    let totalCompleted = 0;
    allModules.forEach(mod => {
        if (userProgress[mod] && userProgress[mod].completed) {
            totalCompleted++;
            updateModuleButton(mod, true);
        }
    });

    // Update stats
    document.getElementById('statModulosConcluidos').textContent = totalCompleted;
    document.getElementById('statCertificados').textContent = totalCompleted;

    // Calculate trail progress
    const trails = {
        'onboarding': ['mod-onboarding-1','mod-onboarding-2','mod-onboarding-3','mod-onboarding-4','mod-onboarding-5','mod-onboarding-6','mod-onboarding-7','mod-onboarding-8','mod-onboarding-9'],
        'relacionamento': ['mod-rel-1','mod-rel-2','mod-rel-3','mod-rel-4','mod-rel-5','mod-rel-6','mod-rel-7','mod-rel-8','mod-rel-9','mod-rel-10','mod-astec-1','mod-astec-2','mod-astec-3','mod-astec-4','mod-astec-5','mod-back-1','mod-back-2','mod-back-3','mod-back-4','mod-rec-1','mod-rec-2','mod-rec-3','mod-rec-4','mod-rec-5'],
        'juridico': ['mod-jur-1','mod-jur-2','mod-jur-3','mod-jur-4'],
        'compliance': ['mod-comp-1','mod-comp-2','mod-comp-3','mod-comp-4','mod-comp-5']
    };

    for (const [trailName, modules] of Object.entries(trails)) {
        let completed = 0;
        modules.forEach(mod => {
            if (userProgress[mod] && userProgress[mod].completed) completed++;
        });
        const pct = Math.round((completed / modules.length) * 100);

        // Update dashboard cards
        const pctEl = document.getElementById('trail-' + trailName + '-pct');
        const barEl = document.getElementById('trail-' + trailName + '-bar');
        if (pctEl) pctEl.textContent = pct + '%';
        if (barEl) barEl.style.width = pct + '%';

        // Update mini progress
        const countEl = document.getElementById('trail-' + trailName + '-count');
        const miniBarEl = document.getElementById('trail-' + trailName + '-mini-bar');
        if (countEl) countEl.textContent = completed + '/' + modules.length;
        if (miniBarEl) miniBarEl.style.width = pct + '%';

        // Update trail pages
        const trailPctEl = document.getElementById(trailName + '-percent');
        const trailFillEl = document.getElementById(trailName + '-fill');
        const trailProgEl = document.getElementById(trailName + '-progress');
        if (trailPctEl) trailPctEl.textContent = pct + '%';
        if (trailFillEl) trailFillEl.style.width = pct + '%';
        if (trailProgEl) trailProgEl.textContent = pct + '%';
    }

    // Legacy: update old progress bar and steps (for backward compat)
    const legacyModules = ['mod1', 'mod2', 'mod3', 'mod4', 'mod5'];
    let legacyCompleted = 0;
    legacyModules.forEach(mod => {
        if (userProgress[mod] && userProgress[mod].completed) legacyCompleted++;
    });
    const legacyPct = Math.round((legacyCompleted / 5) * 100);
    const progressFill = document.getElementById('progressFill');
    const progressPercent = document.getElementById('progressPercent');
    if (progressFill) progressFill.style.width = legacyPct + '%';
    if (progressPercent) progressPercent.textContent = legacyPct + '%';
    for (let i = 1; i <= 5; i++) {
        const step = document.getElementById('step-' + i);
        if (step) {
            if (i <= legacyCompleted) {
                step.classList.add('completed');
                step.classList.remove('active');
            } else if (i === legacyCompleted + 1) {
                step.classList.add('active');
                step.classList.remove('completed');
            } else {
                step.classList.remove('active', 'completed');
            }
        }
    }
}

function markComplete(moduleId) {
    if (!currentUser) {
        showNotification('Faça login para marcar progresso', 'error');
        return;
    }

    // Check if already completed - offer to unmark
    if (userProgress[moduleId] && userProgress[moduleId].completed) {
        if (confirm('Este módulo já está marcado como concluído. Deseja remover a conclusão?')) {
            delete userProgress[moduleId];
            localStorage.setItem(CONFIG.STORAGE_PROGRESS + '_' + currentUser.email, JSON.stringify(userProgress));
            updateDashboard();
            updateModuleButton(moduleId, false);
            showNotification('Conclusão removida.', 'info');
        }
        return;
    }

    // Confirm before marking complete
    if (!confirm('Deseja marcar este módulo como concluído?')) {
        return;
    }

    userProgress[moduleId] = {
        completed: true,
        date: new Date().toISOString()
    };

    // Save progress
    localStorage.setItem(CONFIG.STORAGE_PROGRESS + '_' + currentUser.email, JSON.stringify(userProgress));

    // Update UI
    updateDashboard();
    updateModuleButton(moduleId, true);

        addNotification('Módulo concluído', 'Você concluiu o módulo com sucesso. Continue sua trilha!', 'success');
        addActivity('module_complete', 'Módulo concluído', 'Módulo ' + moduleId + ' marcado como concluído');
    checkAchievements();
    showNotification('Módulo concluído! Progresso salvo.', 'success');
}

function updateModuleButton(moduleId, completed) {
    const btn = document.getElementById('btn-complete-' + moduleId);
    if (!btn) return;
    if (completed) {
        btn.classList.add('completed');
        btn.innerHTML = '<i class="fas fa-check-circle"></i> Concluído (clique para desmarcar)';
        btn.disabled = false;
    } else {
        btn.classList.remove('completed');
        btn.innerHTML = '<i class="fas fa-check"></i> Marcar como concluído';
        btn.disabled = false;
    }
}

function loadModuleContent(moduleId) {
    const moduleData = {
        // Onboarding
        'mod-onboarding-1': { title: 'Boas-vindas', icon: 'fa-hand-sparkles', desc: 'Apresentação da empresa, equipe e expectativas para sua jornada na Canopus Construtora.', trail: 'Onboarding Geral' },
        'mod-onboarding-2': { title: 'História da Empresa', icon: 'fa-landmark', desc: 'Trajetória, marcos e conquistas que construíram a Canopus Construtora.', trail: 'Onboarding Geral' },
        'mod-onboarding-3': { title: 'Cultura e Valores', icon: 'fa-heart', desc: 'Os princípios que norteiam nossas decisões e relacionamentos.', trail: 'Onboarding Geral' },
        'mod-onboarding-4': { title: 'Estrutura Organizacional', icon: 'fa-sitemap', desc: 'Conheça os departamentos, hierarquia e fluxos de comunicação interna.', trail: 'Onboarding Geral' },
        'mod-onboarding-5': { title: 'Comunicação Interna', icon: 'fa-comments', desc: 'Canais, ferramentas e boas práticas de comunicação entre as áreas.', trail: 'Onboarding Geral' },
        'mod-onboarding-6': { title: 'Postura Profissional', icon: 'fa-user-tie', desc: 'Ética, conduta, vestimenta e comportamento esperado no ambiente corporativo.', trail: 'Onboarding Geral' },
        'mod-onboarding-7': { title: 'Sistemas Utilizados', icon: 'fa-laptop-code', desc: 'Tour pelas ferramentas e sistemas que você utilizará no dia a dia.', trail: 'Onboarding Geral' },
        'mod-onboarding-8': { title: 'Jornada do Cliente', icon: 'fa-handshake', desc: 'Entenda o ciclo completo do cliente na Canopus Construtora.', trail: 'Onboarding Geral' },
        'mod-onboarding-9': { title: 'Encerramento', icon: 'fa-flag-checkered', desc: 'Resumo, próximos passos e avaliação do onboarding.', trail: 'Onboarding Geral' },
        // Relacionamento
        'mod-rel-1': { title: 'Jornada do Cliente', icon: 'fa-route', desc: 'Mapeamento completo da experiência do cliente com a Canopus Construtora.', trail: 'Relacionamento' },
        'mod-rel-2': { title: 'Atendimento Humanizado', icon: 'fa-smile-beam', desc: 'Técnicas de empatia, escuta ativa e conexão genuína com o cliente.', trail: 'Relacionamento' },
        'mod-rel-3': { title: 'Escrita Encantadora', icon: 'fa-pen-fancy', desc: 'Redação de e-mails, mensagens e documentos com tom profissional e acolhedor.', trail: 'Relacionamento' },
        'mod-rel-4': { title: 'Comunicação Profissional', icon: 'fa-comment-dots', desc: 'Protocolos de comunicação verbal e não verbal em todos os canais.', trail: 'Relacionamento' },
        'mod-rel-5': { title: 'Gestão de Conflitos', icon: 'fa-balance-scale-right', desc: 'Estratégias de negociação, mediação e resolução de situações delicadas.', trail: 'Relacionamento' },
        'mod-rel-6': { title: 'SLA e Prazos', icon: 'fa-stopwatch', desc: 'Gerenciamento de tempos de resposta, escalação e cumprimento de acordos.', trail: 'Relacionamento' },
        'mod-rel-7': { title: 'Fluxos Operacionais', icon: 'fa-project-diagram', desc: 'Processos, checklists e procedimentos do dia a dia do relacionamento.', trail: 'Relacionamento' },
        'mod-rel-8': { title: 'Sistemas Internos', icon: 'fa-desktop', desc: 'Treinamento prático nas plataformas e ferramentas utilizadas pela área.', trail: 'Relacionamento' },
        'mod-rel-9': { title: 'Modelos de Resposta', icon: 'fa-reply-all', desc: 'Templates, scripts e respostas padronizadas para situações recorrentes.', trail: 'Relacionamento' },
        'mod-rel-10': { title: 'FAQ Operacional', icon: 'fa-question-circle', desc: 'Perguntas e respostas rápidas para o dia a dia operacional.', trail: 'Relacionamento' },
        // ASTEC
        'mod-astec-1': { title: 'Fluxo de Assistência Técnica', icon: 'fa-clipboard-list', desc: 'Processo completo de abertura, acompanhamento e encerramento de assistências.', trail: 'Relacionamento — ASTEC' },
        'mod-astec-2': { title: 'Vistorias', icon: 'fa-search', desc: 'Procedimentos de vistoria técnica, checklists e documentação.', trail: 'Relacionamento — ASTEC' },
        'mod-astec-3': { title: 'Garantias', icon: 'fa-shield-alt', desc: 'Gestão de garantias, prazos legais e comunicação com o cliente.', trail: 'Relacionamento — ASTEC' },
        'mod-astec-4': { title: 'Chamados', icon: 'fa-ticket-alt', desc: 'Abertura, priorização, acompanhamento e resolução de chamados técnicos.', trail: 'Relacionamento — ASTEC' },
        'mod-astec-5': { title: 'SLA Técnico', icon: 'fa-clock', desc: 'Prazos de atendimento técnico, escalação e indicadores de performance.', trail: 'Relacionamento — ASTEC' },
        // Backoffice
        'mod-back-1': { title: 'Fluxos Internos', icon: 'fa-exchange-alt', desc: 'Mapeamento dos processos internos e fluxos de trabalho do backoffice.', trail: 'Relacionamento — Backoffice' },
        'mod-back-2': { title: 'Processos Administrativos', icon: 'fa-tasks', desc: 'Rotinas administrativas, documentação e controles operacionais.', trail: 'Relacionamento — Backoffice' },
        'mod-back-3': { title: 'Comunicação entre Áreas', icon: 'fa-network-wired', desc: 'Interação eficiente entre departamentos e troca de informações.', trail: 'Relacionamento — Backoffice' },
        'mod-back-4': { title: 'Controles Internos', icon: 'fa-clipboard-check', desc: 'Auditoria, conformidade e monitoramento de processos internos.', trail: 'Relacionamento — Backoffice' },
        // Recuperação de Crédito
        'mod-rec-1': { title: 'Negociação', icon: 'fa-handshake', desc: 'Técnicas de negociação para acordos e renegociações de contratos.', trail: 'Relacionamento — Recuperação de Crédito' },
        'mod-rec-2': { title: 'Cobrança Humanizada', icon: 'fa-heart', desc: 'Abordagem respeitosa e eficaz para cobrança e inadimplência.', trail: 'Relacionamento — Recuperação de Crédito' },
        'mod-rec-3': { title: 'Fluxos Financeiros', icon: 'fa-chart-pie', desc: 'Entendimento dos fluxos de pagamento, repasse e conciliação.', trail: 'Relacionamento — Recuperação de Crédito' },
        'mod-rec-4': { title: 'Acordos', icon: 'fa-file-contract', desc: 'Formalização, acompanhamento e cumprimento de acordos negociados.', trail: 'Relacionamento — Recuperação de Crédito' },
        'mod-rec-5': { title: 'Indicadores', icon: 'fa-chart-bar', desc: 'KPIs de recuperação, taxas de sucesso e análise de resultados.', trail: 'Relacionamento — Recuperação de Crédito' },
        // Jurídico
        'mod-jur-1': { title: 'Contratos', icon: 'fa-file-signature', desc: 'Tipos de contratos, cláusulas essenciais e pontos de atenção na construtora.', trail: 'Jurídico' },
        'mod-jur-2': { title: 'Fluxos Jurídicos', icon: 'fa-stream', desc: 'Processos internos do jurídico, aprovações e tramitação de documentos.', trail: 'Jurídico' },
        'mod-jur-3': { title: 'Comunicação Jurídica', icon: 'fa-gavel', desc: 'Redação jurídica, linguagem técnica e comunicação com partes externas.', trail: 'Jurídico' },
        'mod-jur-4': { title: 'Padronizações', icon: 'fa-ruler-combined', desc: 'Modelos, templates e padrões documentais do departamento jurídico.', trail: 'Jurídico' },
        // Compliance
        'mod-comp-1': { title: 'Ética Corporativa', icon: 'fa-handshake', desc: 'Princípios éticos, valores e condutas esperadas em todas as interações.', trail: 'Compliance' },
        'mod-comp-2': { title: 'LGPD', icon: 'fa-user-shield', desc: 'Lei Geral de Proteção de Dados: direitos, obrigações e boas práticas.', trail: 'Compliance' },
        'mod-comp-3': { title: 'Segurança da Informação', icon: 'fa-lock', desc: 'Proteção de dados, senhas, acessos e prevenção a ameaças digitais.', trail: 'Compliance' },
        'mod-comp-4': { title: 'Conduta Profissional', icon: 'fa-user-check', desc: 'Comportamento esperado, conflitos de interesse e relacionamento com terceiros.', trail: 'Compliance' },
        'mod-comp-5': { title: 'Políticas Internas', icon: 'fa-file-alt', desc: 'Regulamentos, normas e procedimentos internos da empresa.', trail: 'Compliance' }
    };

    const data = moduleData[moduleId] || { title: 'Módulo', icon: 'fa-book', desc: 'Conteúdo em desenvolvimento. Em breve, material completo estará disponível.', trail: 'Trilha' };

    document.getElementById('mod-badge').innerHTML = '<i class="fas ' + data.icon + '"></i> ' + data.trail;
    const modTitleEl = document.getElementById('mod-title');
    modTitleEl.textContent = data.title;
    modTitleEl.dataset.moduleId = moduleId;
    document.getElementById('mod-desc').textContent = data.desc;
    document.getElementById('mod-hero-title').innerHTML = '<i class="fas ' + data.icon + '"></i> ' + data.title;
    document.getElementById('mod-hero-desc').textContent = data.desc;

    // Load slide content if available
    loadModuleSlides(moduleId, data);

    // Update button state
    const btn = document.getElementById('mod-hero-btn');
    if (userProgress[moduleId] && userProgress[moduleId].completed) {
        btn.innerHTML = '<i class="fas fa-check-circle"></i> Concluído (clique para desmarcar)';
        btn.onclick = function() { markComplete(moduleId); };
    } else {
        btn.innerHTML = '<i class="fas fa-check-circle"></i> Concluir Módulo';
        btn.onclick = function() { markComplete(moduleId); };
    }
}

function loadModuleSlides(moduleId, data) {
    const slidesContainer = document.getElementById('mod-slides-container');
    if (!slidesContainer) return;

    const slides = MODULE_CONTENT[moduleId];
    if (!slides || !slides.slides || slides.slides.length === 0) {
        slidesContainer.innerHTML = '<div class="empty-state"><i class="fas fa-book-open"></i><h3>Conteúdo em desenvolvimento</h3><p>Os materiais deste módulo serão adicionados em breve pela equipe de conteúdo.</p></div>';
        return;
    }

    let html = '<div class="slides-wrapper" style="margin-bottom: 24px;">';
    html += '<div style="display: flex; gap: 8px; margin-bottom: 16px; overflow-x: auto; padding-bottom: 8px;">';

    slides.slides.forEach((slide, idx) => {
        html += '<button class="slide-tab" id="slide-tab-' + idx + '" onclick="showSlide(' + idx + ')" style="padding: 8px 16px; border: 1.5px solid var(--borda); border-radius: 8px; background: ' + (idx === 0 ? 'var(--turquesa)' : 'white') + '; color: ' + (idx === 0 ? 'white' : 'var(--texto)') + '; font-size: 13px; font-weight: 600; cursor: pointer; transition: var(--transition); white-space: nowrap; font-family: Inter, sans-serif;">' + (idx + 1) + '. ' + slide.title + '</button>';
    });

    html += '</div>';
    html += '<div class="slides-content">';

    slides.slides.forEach((slide, idx) => {
        html += '<div class="slide-panel" id="slide-panel-' + idx + '" style="display: ' + (idx === 0 ? 'block' : 'none') + '; background: white; border-radius: var(--radius); padding: 32px; box-shadow: var(--sombra); border: 1px solid var(--borda);">';
        html += '<h3 style="font-family: Oswald, sans-serif; font-size: 22px; color: var(--azul-escuro); margin-bottom: 16px;"><i class="fas fa-book-open" style="color: var(--turquesa); margin-right: 10px;"></i>' + slide.title + '</h3>';
        html += '<div style="font-size: 15px; line-height: 1.8; color: var(--texto-leve);">';
        html += '<p>' + slide.text + '</p>';
        html += '</div>';
        html += '<div style="margin-top: 20px; display: flex; justify-content: space-between; align-items: center;">';
        html += '<span style="font-size: 12px; color: var(--cinza);">Slide ' + (idx + 1) + ' de ' + slides.slides.length + '</span>';
        if (idx < slides.slides.length - 1) {
            html += '<button class="btn btn-primary" onclick="showSlide(' + (idx + 1) + ')" style="padding: 8px 16px; font-size: 13px;"><i class="fas fa-arrow-right"></i> Próximo slide</button>';
        }
        html += '</div>';
        html += '</div>';
    });

    html += '</div></div>';
    slidesContainer.innerHTML = html;
}

function showSlide(index) {
    document.querySelectorAll('.slide-panel').forEach((panel, idx) => {
        panel.style.display = idx === index ? 'block' : 'none';
    });
    document.querySelectorAll('.slide-tab').forEach((tab, idx) => {
        tab.style.background = idx === index ? 'var(--turquesa)' : 'white';
        tab.style.color = idx === index ? 'white' : 'var(--texto)';
        tab.style.borderColor = idx === index ? 'var(--turquesa)' : 'var(--borda)';
    });
}

// Module content database - comprehensive slide content for all modules
const MODULE_CONTENT = {
    // Onboarding
    'mod-onboarding-1': {
        slides: [
            { title: 'Bem-vindo à Canopus Construtora', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Nossa Missão', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Sua Jornada Começa Agora', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    'mod-onboarding-2': {
        slides: [
            { title: 'Fundada em 2008', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Marcos Importantes', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Reconhecimentos', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    'mod-onboarding-3': {
        slides: [
            { title: 'Nossos Valores', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Cultura de Feedback', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Diversidade e Inclusão', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    'mod-onboarding-4': {
        slides: [
            { title: 'Estrutura Organizacional', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Diretoria de Relacionamento', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Canais de Comunicação', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    'mod-onboarding-5': {
        slides: [
            { title: 'Comunicação Interna', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Reuniões e Cerimônias', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Etiqueta Digital', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    'mod-onboarding-6': {
        slides: [
            { title: 'Postura Profissional', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Ética e Conduta', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Home Office e Flexibilidade', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    'mod-onboarding-7': {
        slides: [
            { title: 'Sistemas Principais', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Segurança da Informação', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Suporte Técnico', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    'mod-onboarding-8': {
        slides: [
            { title: 'Jornada do Cliente', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Nosso Diferencial', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Indicadores de Satisfação', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    'mod-onboarding-9': {
        slides: [
            { title: 'Parabéns!', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Próximos Passos', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Você faz a diferença', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    // Relacionamento
    'mod-rel-1': {
        slides: [
            { title: 'Jornada do Cliente Canopus', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Personas de Clientes', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Pontos de Dor vs. Delight', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    'mod-rel-2': {
        slides: [
            { title: 'Atendimento Humanizado', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Técnica HEARD', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Tom de Voz Canopus', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    'mod-rel-3': {
        slides: [
            { title: 'Escrita Encantadora', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Palavras que Encantam vs. Frustram', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Templates Inteligentes', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    'mod-rel-4': {
        slides: [
            { title: 'Comunicação Profissional', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Comunicação Não-Verbal', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Comunicação em Canais Digitais', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    'mod-rel-5': {
        slides: [
            { title: 'Gestão de Conflitos', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Negociação Colaborativa', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Quando Escalar?', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    'mod-rel-6': {
        slides: [
            { title: 'SLA — Service Level Agreement', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Gestão de Prazos', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Escalação Inteligente', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    'mod-rel-7': {
        slides: [
            { title: 'Fluxos Operacionais', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Checklists de Qualidade', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Métricas de Performance', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    'mod-rel-8': {
        slides: [
            { title: 'Sistemas Internos', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Navegação no CRM', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Integração entre Sistemas', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    'mod-rel-9': {
        slides: [
            { title: 'Modelos de Resposta', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Personalização de Templates', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Manutenção da Biblioteca', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    'mod-rel-10': {
        slides: [
            { title: 'FAQ Operacional', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Atualizações e Versionamento', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Contribuição Colaborativa', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    // ASTEC
    'mod-astec-1': {
        slides: [
            { title: 'Fluxo de Assistência Técnica', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Classificação de Prioridades', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Protocolo e Acompanhamento', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    'mod-astec-2': {
        slides: [
            { title: 'Vistorias Técnicas', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Checklist de Vistoria', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Relatório de Vistoria', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    'mod-astec-3': {
        slides: [
            { title: 'Garantias Canopus', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Cobertura e Exclusões', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Processo de Acionamento', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    'mod-astec-4': {
        slides: [
            { title: 'Gestão de Chamados', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Priorização e Escalonamento', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Indicadores ASTEC', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    'mod-astec-5': {
        slides: [
            { title: 'SLA Técnico', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Penalidades e Compensações', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Melhoria Contínua', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    // Backoffice
    'mod-back-1': {
        slides: [
            { title: 'Fluxos Internos', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Mapeamento de Processos', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Automação e RPA', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    'mod-back-2': {
        slides: [
            { title: 'Processos Administrativos', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Controles e Conferências', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Qualidade na Execução', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    'mod-back-3': {
        slides: [
            { title: 'Comunicação entre Áreas', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Protocolos de Interação', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Gestão de Conflitos Interdepartamentais', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    'mod-back-4': {
        slides: [
            { title: 'Controles Internos', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Conformidade e Regulamentação', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Indicadores de Governança', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    // Recuperação de Crédito
    'mod-rec-1': {
        slides: [
            { title: 'Negociação de Acordos', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Estratégias de Negociação', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Formalização do Acordo', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    'mod-rec-2': {
        slides: [
            { title: 'Cobrança Humanizada', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Fases da Cobrança', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Canais de Cobrança', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    'mod-rec-3': {
        slides: [
            { title: 'Fluxos Financeiros', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Conciliação e Controles', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Indicadores Financeiros', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    'mod-rec-4': {
        slides: [
            { title: 'Formalização de Acordos', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Aprovações e Limites', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Acompanhamento Pós-Acordo', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    'mod-rec-5': {
        slides: [
            { title: 'Indicadores de Recuperação', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Dashboards e Relatórios', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Metas e Reconhecimento', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    // Jurídico
    'mod-jur-1': {
        slides: [
            { title: 'Tipos de Contratos', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Cláusulas Essenciais', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Pontos de Atenção', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    'mod-jur-2': {
        slides: [
            { title: 'Fluxos Jurídicos', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Tramitação de Documentos', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Comunicação com Partes Externas', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    'mod-jur-3': {
        slides: [
            { title: 'Redação Jurídica', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Linguagem Técnica vs. Acessível', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Padronização de Documentos', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    'mod-jur-4': {
        slides: [
            { title: 'Padronizações Documentais', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Gestão de Templates', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Uso e Compliance', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    // Compliance
    'mod-comp-1': {
        slides: [
            { title: 'Ética Corporativa', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Princípios Fundamentais', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Conflitos de Interesse', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    'mod-comp-2': {
        slides: [
            { title: 'LGPD — Visão Geral', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Direitos dos Titulares', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Obrigações da Canopus', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    'mod-comp-3': {
        slides: [
            { title: 'Segurança da Informação', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Controles de Acesso', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Resposta a Incidentes', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    'mod-comp-4': {
        slides: [
            { title: 'Conduta Profissional', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Relacionamento com Terceiros', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Programa de Integridade', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    },
    'mod-comp-5': {
        slides: [
            { title: 'Políticas Internas', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Ciclo de Vida das Políticas', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' },
            { title: 'Consequências do Não-Cumprimento', text: 'Conteúdo em desenvolvimento. Material completo será disponibilizado em breve.' }
        ]
    }
};function markCompleteModuleFromPage() {
    // Get current module from the page context
    const currentModule = document.getElementById('mod-title')?.dataset?.moduleId;
    if (currentModule) {
        markComplete(currentModule);
    } else {
        showNotification('Erro ao processar. Tente novamente.', 'error');
    }
}

// Store current module ID for the generic page
let currentModuleId = null;


// ==================== ADMIN DASHBOARD ====================

function updateAdminDashboard() {
    if (!currentUser || currentRole !== 'admin') return;

    // Load all users
    const usersData = localStorage.getItem(CONFIG.STORAGE_USERS);
    allUsers = usersData ? JSON.parse(usersData) : [];

    // Update stats
    document.getElementById('adminTotalUsers').textContent = allUsers.length;

    let totalCompleted = 0;
    let totalProgress = 0;
    let totalCerts = 0;
    const totalModules = 42; // All modules across all trails

    allUsers.forEach(user => {
        const progress = localStorage.getItem(CONFIG.STORAGE_PROGRESS + '_' + user.email);
        if (progress) {
            const p = JSON.parse(progress);
            const completed = Object.values(p).filter(v => v.completed).length;
            totalCompleted += completed;
            totalProgress += completed;
            totalCerts += completed;
        }
    });

    document.getElementById('adminCompleted').textContent = totalCompleted;
    document.getElementById('adminCerts').textContent = totalCerts;

    const avgProgress = allUsers.length > 0 ? Math.round((totalProgress / (allUsers.length * totalModules)) * 100) : 0;
    document.getElementById('adminAvgProgress').textContent = avgProgress + '%';

    // Update table
    const tbody = document.getElementById('adminTableBody');
    tbody.innerHTML = '';

    allUsers.forEach(user => {
        const progress = localStorage.getItem(CONFIG.STORAGE_PROGRESS + '_' + user.email);
        let completed = 0;
        let percent = 0;
        if (progress) {
            const p = JSON.parse(progress);
            completed = Object.values(p).filter(v => v.completed).length;
            percent = Math.round((completed / totalModules) * 100);
        }

        const row = document.createElement('tr');
        row.innerHTML = `
            <td><strong>${escapeHtml(user.name)}</strong></td>
            <td>${escapeHtml(user.email)}</td>
            <td>
                <div class="progress-cell">
                    <div class="bar"><div class="bar-fill" style="width:${percent}%"></div></div>
                    <span class="percent">${percent}%</span>
                </div>
            </td>
            <td>${completed}/${totalModules}</td>
            <td><span class="status-badge ${percent === 100 ? 'active' : 'inactive'}">${percent === 100 ? 'Concluído' : 'Em andamento'}</span></td>
        `;
        tbody.appendChild(row);
    });

    // Update users table in admin-users page
    const usersTbody = document.getElementById('usersTableBody');
    if (usersTbody) {
        usersTbody.innerHTML = '';
        allUsers.forEach(user => {
            const progress = localStorage.getItem(CONFIG.STORAGE_PROGRESS + '_' + user.email);
            let completed = 0;
            let percent = 0;
            if (progress) {
                const p = JSON.parse(progress);
                completed = Object.values(p).filter(v => v.completed).length;
                percent = Math.round((completed / totalModules) * 100);
            }

            const row = document.createElement('tr');
            row.innerHTML = `
                <td><strong>${escapeHtml(user.name)}</strong></td>
                <td>${escapeHtml(user.email)}</td>
                <td>${new Date(user.registeredAt).toLocaleDateString('pt-BR')}</td>
                <td>
                    <div class="progress-cell">
                        <div class="bar"><div class="bar-fill" style="width:${percent}%"></div></div>
                        <span class="percent">${percent}%</span>
                    </div>
                </td>
                <td>${completed}</td>
                <td><button class="btn btn-secondary" style="padding:6px 12px;font-size:12px;" onclick="viewUserDetail('${escapeHtml(user.email)}')"><i class="fas fa-eye"></i> Ver</button></td>
            `;
            usersTbody.appendChild(row);
        });
    }
}

function registerUser(name, email) {
    const usersData = localStorage.getItem(CONFIG.STORAGE_USERS);
    let users = usersData ? JSON.parse(usersData) : [];

    // Check if user already exists
    const exists = users.find(u => u.email === email);
    if (!exists) {
        users.push({
            name: name,
            email: email,
            registeredAt: new Date().toISOString()
        });
        localStorage.setItem(CONFIG.STORAGE_USERS, JSON.stringify(users));
    }
}

// ==================== CERTIFICATES ====================

function updateCertificates() {
    const container = document.getElementById('certificatesContainer');
    const emptyState = document.getElementById('emptyCerts');

    if (!currentUser) return;

    const allModules = [
        { id: 'mod1', name: 'Atendimento ao Cliente', hours: '2h30', trail: 'Relacionamento (Legado)' },
        { id: 'mod2', name: 'Comunicação Efetiva', hours: '2h', trail: 'Relacionamento (Legado)' },
        { id: 'mod3', name: 'SAC e Ouvidoria', hours: '2h', trail: 'Relacionamento (Legado)' },
        { id: 'mod4', name: 'Relacionamento com Clientes', hours: '2h30', trail: 'Relacionamento (Legado)' },
        { id: 'mod5', name: 'Gestão e Liderança', hours: '2h', trail: 'Relacionamento (Legado)' },
        // Onboarding
        { id: 'mod-onboarding-1', name: 'Boas-vindas', hours: '30min', trail: 'Onboarding Geral' },
        { id: 'mod-onboarding-2', name: 'História da Empresa', hours: '45min', trail: 'Onboarding Geral' },
        { id: 'mod-onboarding-3', name: 'Cultura e Valores', hours: '40min', trail: 'Onboarding Geral' },
        { id: 'mod-onboarding-4', name: 'Estrutura Organizacional', hours: '35min', trail: 'Onboarding Geral' },
        { id: 'mod-onboarding-5', name: 'Comunicação Interna', hours: '30min', trail: 'Onboarding Geral' },
        { id: 'mod-onboarding-6', name: 'Postura Profissional', hours: '35min', trail: 'Onboarding Geral' },
        { id: 'mod-onboarding-7', name: 'Sistemas Utilizados', hours: '50min', trail: 'Onboarding Geral' },
        { id: 'mod-onboarding-8', name: 'Jornada do Cliente', hours: '40min', trail: 'Onboarding Geral' },
        { id: 'mod-onboarding-9', name: 'Encerramento', hours: '25min', trail: 'Onboarding Geral' },
        // Relacionamento
        { id: 'mod-rel-1', name: 'Jornada do Cliente', hours: '45min', trail: 'Relacionamento' },
        { id: 'mod-rel-2', name: 'Atendimento Humanizado', hours: '50min', trail: 'Relacionamento' },
        { id: 'mod-rel-3', name: 'Escrita Encantadora', hours: '40min', trail: 'Relacionamento' },
        { id: 'mod-rel-4', name: 'Comunicação Profissional', hours: '45min', trail: 'Relacionamento' },
        { id: 'mod-rel-5', name: 'Gestão de Conflitos', hours: '50min', trail: 'Relacionamento' },
        { id: 'mod-rel-6', name: 'SLA e Prazos', hours: '35min', trail: 'Relacionamento' },
        { id: 'mod-rel-7', name: 'Fluxos Operacionais', hours: '40min', trail: 'Relacionamento' },
        { id: 'mod-rel-8', name: 'Sistemas Internos', hours: '45min', trail: 'Relacionamento' },
        { id: 'mod-rel-9', name: 'Modelos de Resposta', hours: '35min', trail: 'Relacionamento' },
        { id: 'mod-rel-10', name: 'FAQ Operacional', hours: '30min', trail: 'Relacionamento' },
        // ASTEC
        { id: 'mod-astec-1', name: 'Fluxo de Assistência Técnica', hours: '40min', trail: 'ASTEC' },
        { id: 'mod-astec-2', name: 'Vistorias', hours: '35min', trail: 'ASTEC' },
        { id: 'mod-astec-3', name: 'Garantias', hours: '40min', trail: 'ASTEC' },
        { id: 'mod-astec-4', name: 'Chamados', hours: '35min', trail: 'ASTEC' },
        { id: 'mod-astec-5', name: 'SLA Técnico', hours: '30min', trail: 'ASTEC' },
        // Backoffice
        { id: 'mod-back-1', name: 'Fluxos Internos', hours: '35min', trail: 'Backoffice' },
        { id: 'mod-back-2', name: 'Processos Administrativos', hours: '40min', trail: 'Backoffice' },
        { id: 'mod-back-3', name: 'Comunicação entre Áreas', hours: '30min', trail: 'Backoffice' },
        { id: 'mod-back-4', name: 'Controles Internos', hours: '35min', trail: 'Backoffice' },
        // Recuperação de Crédito
        { id: 'mod-rec-1', name: 'Negociação', hours: '45min', trail: 'Recuperação de Crédito' },
        { id: 'mod-rec-2', name: 'Cobrança Humanizada', hours: '40min', trail: 'Recuperação de Crédito' },
        { id: 'mod-rec-3', name: 'Fluxos Financeiros', hours: '35min', trail: 'Recuperação de Crédito' },
        { id: 'mod-rec-4', name: 'Acordos', hours: '40min', trail: 'Recuperação de Crédito' },
        { id: 'mod-rec-5', name: 'Indicadores', hours: '30min', trail: 'Recuperação de Crédito' },
        // Jurídico
        { id: 'mod-jur-1', name: 'Contratos', hours: '90min', trail: 'Jurídico' },
        { id: 'mod-jur-2', name: 'Fluxos Jurídicos', hours: '60min', trail: 'Jurídico' },
        { id: 'mod-jur-3', name: 'Comunicação Jurídica', hours: '60min', trail: 'Jurídico' },
        { id: 'mod-jur-4', name: 'Padronizações', hours: '50min', trail: 'Jurídico' },
        // Compliance
        { id: 'mod-comp-1', name: 'Ética Corporativa', hours: '60min', trail: 'Compliance' },
        { id: 'mod-comp-2', name: 'LGPD', hours: '90min', trail: 'Compliance' },
        { id: 'mod-comp-3', name: 'Segurança da Informação', hours: '60min', trail: 'Compliance' },
        { id: 'mod-comp-4', name: 'Conduta Profissional', hours: '50min', trail: 'Compliance' },
        { id: 'mod-comp-5', name: 'Políticas Internas', hours: '60min', trail: 'Compliance' }
    ];

    let hasCerts = false;
    let htmlCerts = '';

    allModules.forEach(mod => {
        if (userProgress[mod.id] && userProgress[mod.id].completed) {
            hasCerts = true;
            htmlCerts += `
                <div class="cert-card">
                    <div class="cert-badge"><i class="fas fa-award"></i></div>
                    <h3>${mod.name}</h3>
                    <div class="cert-date" style="font-size:11px;color:var(--cinza);margin-bottom:4px;">${mod.trail}</div>
                    <div class="cert-date">Concluído em ${new Date(userProgress[mod.id].date).toLocaleDateString('pt-BR')}</div>
                    <div class="cert-hours"><i class="fas fa-clock"></i> ${mod.hours} de estudo</div>
                    <div class="cert-actions">
                        <button class="primary" onclick="previewCertificate('${mod.name}', '${mod.hours}')"><i class="fas fa-eye"></i> Visualizar</button>
                        <button onclick="downloadCertificate('${mod.name}')"><i class="fas fa-download"></i> Baixar</button>
                    </div>
                </div>
            `;
        }
    });

    if (hasCerts) {
        container.innerHTML = htmlCerts;
    } else {
        container.innerHTML = '';
        container.appendChild(emptyState);
    }
}

function previewCertificate(moduleName, hours) {
    const modal = document.getElementById('certPreviewModal');
    document.getElementById('certModuleName').textContent = moduleName;
    document.getElementById('certUserNameDisplay').textContent = currentUser ? currentUser.name : 'Colaborador';
    document.getElementById('certHours').textContent = hours;
    document.getElementById('certDate').textContent = new Date().toLocaleDateString('pt-BR');
    modal.classList.add('active');
}

function closeCertPreview() {
    document.getElementById('certPreviewModal').classList.remove('active');
}

function downloadCertificate(moduleName) {
    showNotification('Certificado gerado! Download iniciado.', 'success');
}

// ==================== FAQ ====================

function toggleFaq(element) {
    const item = element.parentElement;
    const wasActive = item.classList.contains('active');

    // Close all
    document.querySelectorAll('.faq-item').forEach(faq => {
        faq.classList.remove('active');
    });

    // Open clicked if wasn't active
    if (!wasActive) {
        item.classList.add('active');
    }
}

function copyToClipboard(btn) {
    const content = btn.parentElement.querySelector('p').textContent;
    navigator.clipboard.writeText(content).then(() => {
        btn.classList.add('copied');
        btn.innerHTML = '<i class="fas fa-check"></i> Copiado!';
        setTimeout(() => {
            btn.classList.remove('copied');
            btn.innerHTML = '<i class="fas fa-copy"></i> Copiar resposta';
        }, 2000);
    });
}

// ==================== CONTENT MANAGER ====================

function switchCmTab(tab) {
    document.querySelectorAll('.cm-tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.cm-panel').forEach(p => p.classList.remove('active'));
    event.target.classList.add('active');
    document.getElementById('cm-panel-' + tab).classList.add('active');
}

function addMaterial() {
    const title = document.getElementById('materialTitle').value.trim();
    const module = document.getElementById('materialModule').value;
    const type = document.getElementById('materialType').value;
    const url = document.getElementById('materialUrl').value.trim();

    if (!title || !module || !type || !url) {
        showNotification('Preencha todos os campos obrigatórios', 'error');
        return;
    }

    showNotification('Material adicionado com sucesso!', 'success');
    resetMaterialForm();
}

function resetMaterialForm() {
    document.getElementById('materialTitle').value = '';
    document.getElementById('materialModule').value = '';
    document.getElementById('materialType').value = '';
    document.getElementById('materialUrl').value = '';
    document.getElementById('materialDesc').value = '';
}

// ==================== FILE UPLOAD ====================

let uploadQueue = [];

function setupDragDrop() {
    const zone = document.getElementById('uploadZone');
    if (!zone) return;

    zone.addEventListener('dragover', (e) => {
        e.preventDefault();
        zone.classList.add('dragover');
    });

    zone.addEventListener('dragleave', () => {
        zone.classList.remove('dragover');
    });

    zone.addEventListener('drop', (e) => {
        e.preventDefault();
        zone.classList.remove('dragover');
        handleFiles(e.dataTransfer.files);
    });
}

function handleFiles(files) {
    const list = document.getElementById('uploadList');

    Array.from(files).forEach(file => {
        const id = 'file-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);
        uploadQueue.push({ id: id, file: file, status: 'pending' });

        const div = document.createElement('div');
        div.className = 'upload-file';
        div.id = id;
        div.innerHTML = `
            <i class="fas fa-file"></i>
            <div class="file-info">
                <div class="file-name">${escapeHtml(file.name)}</div>
                <div class="file-size">${formatFileSize(file.size)}</div>
            </div>
            <div class="file-progress">
                <div class="file-progress-bar" style="width:0%"></div>
            </div>
            <span class="file-status pending">Aguardando</span>
            <button class="file-remove" onclick="removeFile('${id}')"><i class="fas fa-times"></i></button>
        `;
        list.appendChild(div);
    });
}

function removeFile(id) {
    const el = document.getElementById(id);
    if (el) el.remove();
    uploadQueue = uploadQueue.filter(f => f.id !== id);
}

function processUploads() {
    if (uploadQueue.length === 0) {
        showNotification('Nenhum arquivo na fila', 'warning');
        return;
    }

    uploadQueue.forEach(item => {
        const el = document.getElementById(item.id);
        if (!el) return;

        const bar = el.querySelector('.file-progress-bar');
        const status = el.querySelector('.file-status');

        status.textContent = 'Enviando...';
        status.className = 'file-status pending';

        // Simulate upload progress
        let progress = 0;
        const interval = setInterval(() => {
            progress += Math.random() * 30;
            if (progress >= 100) {
                progress = 100;
                clearInterval(interval);
                status.textContent = 'Concluído';
                status.className = 'file-status done';
                bar.style.width = '100%';
            } else {
                bar.style.width = progress + '%';
            }
        }, 300);
    });

    showNotification('Uploads iniciados! Arquivos serão processados.', 'success');
}

function clearUploads() {
    document.getElementById('uploadList').innerHTML = '';
    uploadQueue = [];
}

// ==================== NOTIFICATIONS ====================

function showNotification(message, type) {
    const notif = document.createElement('div');
    notif.className = 'notification ' + type;

    const icons = {
        success: 'fa-check-circle',
        error: 'fa-exclamation-circle',
        info: 'fa-info-circle',
        warning: 'fa-exclamation-triangle'
    };

    notif.innerHTML = `<i class="fas ${icons[type] || 'fa-info-circle'}"></i> ${message}`;
    document.body.appendChild(notif);

    setTimeout(() => {
        notif.style.animation = 'slideOutRight 0.4s ease forwards';
        setTimeout(() => notif.remove(), 400);
    }, 3000);
}

// ==================== SEARCH ====================

function searchContent(query) {
    if (!query || !currentUser) return;
    query = query.toLowerCase().trim();

    if (query.length < 2) return;

    // Search index with keywords mapped to pages
    const searchIndex = [
        { page: 'dashboard', keywords: ['dashboard', 'inicio', 'home', 'principal', 'trilhas', 'progresso', 'certificado'] },
        { page: 'trilha-onboarding', keywords: ['onboarding', 'integração', 'boas-vindas', 'história', 'cultura', 'valores', 'estrutura', 'sistemas'] },
        { page: 'trilha-relacionamento', keywords: ['relacionamento', 'atendimento', 'cliente', 'astec', 'backoffice', 'recuperação', 'crédito', 'cobrança'] },
        { page: 'trilha-juridico', keywords: ['jurídico', 'contratos', 'distrato', 'legal', 'advogado', 'cláusulas'] },
        { page: 'trilha-compliance', keywords: ['compliance', 'lgpd', 'ética', 'segurança', 'informação', 'conduta', 'políticas'] },
        { page: 'faq', keywords: ['faq', 'pergunta', 'dúvida', 'resposta', 'ajuda', 'suporte', 'protocolo', 'script'] },
        { page: 'certificados', keywords: ['certificado', 'conclusão', 'diploma', 'comprovante', 'horas'] },
        { page: 'admin-dashboard', keywords: ['admin', 'painel', 'relatório', 'colaboradores', 'estatísticas'], admin: true },
        { page: 'admin-content', keywords: ['conteúdo', 'material', 'upload', 'arquivo', 'pdf', 'slide'], admin: true },
        { page: 'admin-users', keywords: ['usuários', 'colaboradores', 'cadastro', 'permissão'], admin: true }
    ];

    // Module-specific search
    const moduleKeywords = {
        'mod-onboarding-1': ['boas-vindas', 'apresentação', 'empresa'],
        'mod-onboarding-2': ['história', 'trajetória', 'marcos'],
        'mod-onboarding-3': ['cultura', 'valores', 'princípios'],
        'mod-onboarding-4': ['estrutura', 'organizacional', 'departamentos'],
        'mod-onboarding-5': ['comunicação', 'interna', 'canais'],
        'mod-onboarding-6': ['postura', 'profissional', 'ética', 'conduta'],
        'mod-onboarding-7': ['sistemas', 'ferramentas', 'software'],
        'mod-onboarding-8': ['jornada', 'cliente', 'ciclo'],
        'mod-onboarding-9': ['encerramento', 'avaliação', 'próximos passos'],
        'mod-rel-1': ['jornada', 'cliente', 'experiência'],
        'mod-rel-2': ['atendimento', 'humanizado', 'empatia'],
        'mod-rel-3': ['escrita', 'e-mail', 'redação'],
        'mod-rel-4': ['comunicação', 'verbal', 'protocolo'],
        'mod-rel-5': ['conflito', 'negociação', 'mediação'],
        'mod-rel-6': ['sla', 'prazo', 'tempo', 'resposta'],
        'mod-rel-7': ['fluxo', 'operacional', 'processo'],
        'mod-rel-8': ['sistemas', 'internos', 'plataformas'],
        'mod-rel-9': ['modelos', 'templates', 'scripts', 'respostas'],
        'mod-rel-10': ['faq', 'operacional', 'perguntas frequentes'],
        'mod-astec-1': ['assistência', 'técnica', 'fluxo'],
        'mod-astec-2': ['vistoria', 'inspeção', 'checklist'],
        'mod-astec-3': ['garantia', 'prazo legal', 'defeito'],
        'mod-astec-4': ['chamado', 'ticket', 'suporte'],
        'mod-astec-5': ['sla técnico', 'prazo técnico'],
        'mod-back-1': ['fluxos', 'internos', 'processos'],
        'mod-back-2': ['administrativo', 'documentação', 'rotina'],
        'mod-back-3': ['comunicação', 'áreas', 'departamentos'],
        'mod-back-4': ['controles', 'auditoria', 'conformidade'],
        'mod-rec-1': ['negociação', 'acordo', 'renegociação'],
        'mod-rec-2': ['cobrança', 'humanizada', 'inadimplência'],
        'mod-rec-3': ['financeiro', 'pagamento', 'repasse'],
        'mod-rec-4': ['acordo', 'formalização', 'contrato'],
        'mod-rec-5': ['indicadores', 'kpi', 'resultados'],
        'mod-jur-1': ['contratos', 'cláusulas', 'documentos'],
        'mod-jur-2': ['fluxos', 'jurídicos', 'aprovações'],
        'mod-jur-3': ['redação', 'jurídica', 'linguagem'],
        'mod-jur-4': ['padronizações', 'templates', 'modelos'],
        'mod-comp-1': ['ética', 'corporativa', 'valores'],
        'mod-comp-2': ['lgpd', 'dados', 'privacidade', 'proteção'],
        'mod-comp-3': ['segurança', 'informação', 'senha', 'acesso'],
        'mod-comp-4': ['conduta', 'profissional', 'comportamento'],
        'mod-comp-5': ['políticas', 'regulamentos', 'normas']
    };

    let results = [];
    let matchedModules = [];

    // Search pages
    searchIndex.forEach(item => {
        if (item.admin && currentRole !== 'admin') return;
        const match = item.keywords.some(k => k.includes(query) || query.includes(k));
        if (match) results.push(item.page);
    });

    // Search modules
    for (const [modId, keywords] of Object.entries(moduleKeywords)) {
        const match = keywords.some(k => k.includes(query) || query.includes(k));
        if (match) matchedModules.push(modId);
    }

    // Show results
    const totalResults = results.length + matchedModules.length;

    if (totalResults === 0) {
        return;
    }

    // Navigate to first result if it's a page
    if (results.length > 0) {
        setTimeout(() => navigateTo(results[0]), 300);
    } else if (matchedModules.length > 0) {
        setTimeout(() => navigateTo(matchedModules[0]), 300);
    }
}

// ==================== THEME ====================

function toggleTheme() {
    document.body.classList.toggle('dark-mode');
    const isDark = document.body.classList.contains('dark-mode');
    localStorage.setItem('re_theme', isDark ? 'dark' : 'light');

    // Update icon
    const themeBtn = document.querySelector('.top-btn[title="Tema"] i');
    if (themeBtn) {
        themeBtn.className = isDark ? 'fas fa-sun' : 'fas fa-moon';
    }

    showNotification(isDark ? 'Modo escuro ativado' : 'Modo claro ativado', 'success');
}

function loadTheme() {
    const saved = localStorage.getItem('re_theme');
    if (saved === 'dark') {
        document.body.classList.add('dark-mode');
        const themeBtn = document.querySelector('.top-btn[title="Tema"] i');
        if (themeBtn) themeBtn.className = 'fas fa-sun';
    }
}

function toggleNotifications() {
    showNotification('Nenhuma notificação nova', 'info');
}

// ==================== MODALS ====================

function showAboutModal() {
    showNotification('Relacionamento Ensina v6.0 — Plataforma de Treinamento Canopus', 'info');
}

function viewUserDetail(email) {
    showNotification('Detalhes do usuário: ' + email, 'info');
}

// ==================== UTILITIES ====================

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function setupEventListeners() {
    // Keyboard shortcuts
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            closeCertPreview();
            document.querySelectorAll('.modal-overlay').forEach(m => m.classList.remove('active'));
        }
    });
}

// ==================== CERTIFICATE PREVIEW MODAL ====================
// (Added dynamically to body)
const certModalHtml = `
<div class="cert-preview" id="certPreviewModal">
    <div class="cert-preview-content">
        <button class="cert-preview-close" onclick="closeCertPreview()"><i class="fas fa-times"></i></button>
        <div class="cert-header">
            <h2><i class="fas fa-award" style="color:var(--turquesa);margin-right:8px;"></i>Certificado de Conclusão</h2>
            <p>Canopus Construtora — Relacionamento Ensina</p>
        </div>
        <div class="cert-body">
            <h3>Certificamos que</h3>
            <div class="cert-recipient" id="certUserNameDisplay">Colaborador</div>
            <p>concluiu com êxito o módulo <strong id="certModuleName">Módulo</strong>,<br>com carga horária de <strong id="certHours">0h</strong> de estudo.</p>
            <p style="margin-top:16px;font-size:13px;color:var(--cinza);">Data de emissão: <span id="certDate">--/--/----</span></p>
        </div>
        <div class="cert-footer">
            <div class="cert-signature">
                <div class="line"></div>
                <p>Diretoria de Relacionamento<br>Canopus Construtora</p>
            </div>
            <div style="text-align:center;">
                <div style="width:80px;height:80px;background:linear-gradient(135deg,var(--turquesa),var(--azul-medio));border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 8px;">
                    <i class="fas fa-graduation-cap" style="font-size:32px;color:white;"></i>
                </div>
                <p style="font-size:11px;color:var(--cinza);">Selo de autenticidade<br>Relacionamento Ensina</p>
            </div>
        </div>
    </div>
</div>
`;

// Add modal to body
document.body.insertAdjacentHTML('beforeend', certModalHtml);

console.log('Relacionamento Ensina v6.0 - Sistema inicializado');


// ==================== USER PROFILE FUNCTIONS ====================

function updateProfilePhoto(input) {
    if (!input.files || !input.files[0]) return;

    const file = input.files[0];
    if (!file.type.startsWith('image/')) {
        showNotification('Selecione uma imagem válida (JPG, PNG)', 'error');
        return;
    }
    if (file.size > 2 * 1024 * 1024) {
        showNotification('Imagem muito grande. Máximo 2MB.', 'error');
        return;
    }

    const reader = new FileReader();
    reader.onload = function(e) {
        const img = document.getElementById('profilePhotoImg');
        const icon = document.getElementById('profilePhotoIcon');
        if (img) {
            img.src = e.target.result;
            img.style.display = 'block';
        }
        if (icon) icon.style.display = 'none';

        if (currentUser) {
            localStorage.setItem('re_photo_' + currentUser.email, e.target.result);
        }
        showNotification('Foto de perfil atualizada!', 'success');
        addActivity('profile_update', 'Foto atualizada', 'Foto de perfil alterada');
    };
    reader.readAsDataURL(file);
}

function loadProfilePhoto() {
    if (!currentUser) return;
    const saved = localStorage.getItem('re_photo_' + currentUser.email);
    if (saved) {
        const img = document.getElementById('profilePhotoImg');
        const icon = document.getElementById('profilePhotoIcon');
        if (img) {
            img.src = saved;
            img.style.display = 'block';
        }
        if (icon) icon.style.display = 'none';
    }
}

function updateUserProfilePage() {
    if (!currentUser) return;

    const nameEl = document.getElementById('profileName');
    const emailEl = document.getElementById('profileEmail');
    const roleBadge = document.getElementById('profileRoleBadge');
    const memberSince = document.getElementById('profileMemberSince');

    if (nameEl) nameEl.textContent = currentUser.name;
    if (emailEl) emailEl.textContent = currentUser.email;
    if (roleBadge) {
        roleBadge.textContent = currentRole === 'admin' ? 'Administrador' : 'Colaborador';
        roleBadge.className = currentRole === 'admin' ? 'badge-inline warning' : 'badge-inline success';
    }
    if (memberSince && currentUser.loginTime) {
        memberSince.textContent = new Date(currentUser.loginTime).toLocaleDateString('pt-BR');
    }

    const allModules = [
        'mod1','mod2','mod3','mod4','mod5',
        'mod-onboarding-1','mod-onboarding-2','mod-onboarding-3','mod-onboarding-4','mod-onboarding-5',
        'mod-onboarding-6','mod-onboarding-7','mod-onboarding-8','mod-onboarding-9',
        'mod-rel-1','mod-rel-2','mod-rel-3','mod-rel-4','mod-rel-5','mod-rel-6','mod-rel-7','mod-rel-8','mod-rel-9','mod-rel-10',
        'mod-astec-1','mod-astec-2','mod-astec-3','mod-astec-4','mod-astec-5',
        'mod-back-1','mod-back-2','mod-back-3','mod-back-4',
        'mod-rec-1','mod-rec-2','mod-rec-3','mod-rec-4','mod-rec-5',
        'mod-jur-1','mod-jur-2','mod-jur-3','mod-jur-4',
        'mod-comp-1','mod-comp-2','mod-comp-3','mod-comp-4','mod-comp-5'
    ];

    let completed = 0;
    allModules.forEach(mod => {
        if (userProgress[mod] && userProgress[mod].completed) completed++;
    });

    const totalModules = allModules.length;
    const pct = Math.round((completed / totalModules) * 100);
    const hours = Math.round((completed * 40) / 60);

    const totalModulesEl = document.getElementById('profileTotalModules');
    const totalHoursEl = document.getElementById('profileTotalHours');
    const totalCertsEl = document.getElementById('profileTotalCerts');
    const globalProgressEl = document.getElementById('profileGlobalProgress');

    if (totalModulesEl) totalModulesEl.textContent = completed;
    if (totalHoursEl) totalHoursEl.textContent = hours + 'h';
    if (totalCertsEl) totalCertsEl.textContent = completed;
    if (globalProgressEl) globalProgressEl.textContent = pct + '%';

    loadProfilePhoto();
    loadPreferences();
    checkAchievements();
    renderRecentActivity();
}

function changePassword() {
    const current = document.getElementById('currentPassword');
    const newPass = document.getElementById('newPassword');
    const confirm = document.getElementById('confirmPassword');
    const errorEl = document.getElementById('passwordChangeError');
    const successEl = document.getElementById('passwordChangeSuccess');

    if (!current || !newPass || !confirm) return;

    errorEl.style.display = 'none';
    successEl.style.display = 'none';

    if (!current.value || !newPass.value || !confirm.value) {
        errorEl.textContent = 'Preencha todos os campos.';
        errorEl.style.display = 'block';
        return;
    }

    if (currentRole === 'admin') {
        if (current.value !== CONFIG.ADMIN_PASS) {
            errorEl.textContent = 'Senha atual incorreta.';
            errorEl.style.display = 'block';
            return;
        }
    } else {
        const storedPass = localStorage.getItem('re_pass_' + currentUser.email);
        if (storedPass && current.value !== storedPass) {
            errorEl.textContent = 'Senha atual incorreta.';
            errorEl.style.display = 'block';
            return;
        }
    }

    if (newPass.value.length < 8) {
        errorEl.textContent = 'A nova senha deve ter no mínimo 8 caracteres.';
        errorEl.style.display = 'block';
        return;
    }

    if (newPass.value !== confirm.value) {
        errorEl.textContent = 'As senhas não conferem.';
        errorEl.style.display = 'block';
        return;
    }

    if (currentRole === 'admin') {
        CONFIG.ADMIN_PASS = newPass.value;
    }
    if (currentUser) {
        localStorage.setItem('re_pass_' + currentUser.email, newPass.value);
    }

    successEl.textContent = 'Senha alterada com sucesso!';
    successEl.style.display = 'block';
        addActivity('password_change', 'Senha alterada', 'Senha de acesso atualizada com sucesso');

    current.value = '';
    newPass.value = '';
    confirm.value = '';

    showNotification('Senha atualizada com sucesso!', 'success');
}

function togglePreference(key, value) {
    if (!currentUser) return;
    const prefs = JSON.parse(localStorage.getItem('re_prefs_' + currentUser.email) || '{}');
    prefs[key] = value;
    localStorage.setItem('re_prefs_' + currentUser.email, JSON.stringify(prefs));
    showNotification('Preferência salva!', 'success');
}

function loadPreferences() {
    if (!currentUser) return;
    const prefs = JSON.parse(localStorage.getItem('re_prefs_' + currentUser.email) || '{}');

    const emailNotif = document.getElementById('notifEmail');
    const darkMode = document.getElementById('darkMode');
    const studyReminders = document.getElementById('studyReminders');

    if (emailNotif) emailNotif.checked = prefs.emailNotif !== false;
    if (darkMode) darkMode.checked = prefs.darkMode === true;
    if (studyReminders) studyReminders.checked = prefs.studyReminders !== false;
}

// ==================== NOTIFICATION SYSTEM ====================

let notifications = [];

function loadNotifications() {
    if (!currentUser) return;
    const saved = localStorage.getItem('re_notifications_' + currentUser.email);
    notifications = saved ? JSON.parse(saved) : getDefaultNotifications();
    updateNotificationBadge();
    renderNotifications();
}

function getDefaultNotifications() {
    return [
        { id: 1, title: 'Bem-vindo ao Relacionamento Ensina!', message: 'Complete seu onboarding para começar.', type: 'info', read: false, date: new Date().toISOString() },
        { id: 2, title: 'Nova trilha disponível', message: 'A trilha de Compliance foi atualizada com novos conteúdos.', type: 'success', read: false, date: new Date().toISOString() },
        { id: 3, title: 'Lembrete de estudo', message: 'Você tem módulos pendentes na trilha de Relacionamento.', type: 'warning', read: true, date: new Date(Date.now() - 86400000).toISOString() }
    ];
}

function addNotification(title, message, type = 'info') {
    if (!currentUser) return;
    const notif = {
        id: Date.now(),
        title: title,
        message: message,
        type: type,
        read: false,
        date: new Date().toISOString()
    };
    notifications.unshift(notif);
    if (notifications.length > 50) notifications.pop();
    saveNotifications();
    updateNotificationBadge();
    renderNotifications();
}

function saveNotifications() {
    if (!currentUser) return;
    localStorage.setItem('re_notifications_' + currentUser.email, JSON.stringify(notifications));
}

function updateNotificationBadge() {
    const badge = document.getElementById('notifBadge');
    if (!badge) return;
    const unread = notifications.filter(n => !n.read).length;
    if (unread > 0) {
        badge.textContent = unread > 9 ? '9+' : unread;
        badge.style.display = 'flex';
    } else {
        badge.style.display = 'none';
    }
}

function renderNotifications() {
    const list = document.getElementById('notificationList');
    if (!list) return;

    if (notifications.length === 0) {
        list.innerHTML = '<div style="text-align: center; padding: 32px 20px; color: var(--cinza);"><i class="fas fa-bell-slash" style="font-size: 32px; margin-bottom: 12px; display: block;"></i><p style="font-size: 13px;">Nenhuma notificação</p></div>';
        return;
    }

    let html = '';
    notifications.forEach(notif => {
        const icons = { info: 'fa-info-circle', success: 'fa-check-circle', warning: 'fa-exclamation-triangle', error: 'fa-exclamation-circle' };
        const colors = { info: '#3b82f6', success: '#10b981', warning: '#f59e0b', error: '#dc2626' };
        const date = new Date(notif.date).toLocaleDateString('pt-BR');

        html += '<div style="display: flex; gap: 12px; padding: 12px; border-radius: 10px; margin-bottom: 8px; background: ' + (notif.read ? 'var(--cinza-claro)' : 'white') + '; border: 1px solid ' + (notif.read ? 'var(--borda)' : colors[notif.type] + '40') + '; cursor: pointer; transition: var(--transition);" onclick="markNotificationRead(' + notif.id + ')">';
        html += '<div style="width: 36px; height: 36px; border-radius: 50%; background: ' + colors[notif.type] + '15; display: flex; align-items: center; justify-content: center; flex-shrink: 0;"><i class="fas ' + icons[notif.type] + '" style="color: ' + colors[notif.type] + '; font-size: 14px;"></i></div>';
        html += '<div style="flex: 1; min-width: 0;">';
        html += '<div style="font-size: 13px; font-weight: 600; color: var(--azul-escuro); margin-bottom: 2px;">' + escapeHtml(notif.title) + (notif.read ? '' : ' <span style="width: 6px; height: 6px; background: ' + colors[notif.type] + '; border-radius: 50%; display: inline-block; margin-left: 4px;"></span>') + '</div>';
        html += '<div style="font-size: 12px; color: var(--cinza); line-height: 1.4;">' + escapeHtml(notif.message) + '</div>';
        html += '<div style="font-size: 11px; color: var(--cinza); margin-top: 4px;">' + date + '</div>';
        html += '</div>';
        html += '</div>';
    });

    list.innerHTML = html;
}

function markNotificationRead(id) {
    const notif = notifications.find(n => n.id === id);
    if (notif) {
        notif.read = true;
        saveNotifications();
        updateNotificationBadge();
        renderNotifications();
    }
}

function clearAllNotifications() {
    notifications.forEach(n => n.read = true);
    saveNotifications();
    updateNotificationBadge();
    renderNotifications();
    showNotification('Todas as notificações marcadas como lidas', 'success');
}

function toggleNotifications() {
    const panel = document.getElementById('notificationPanel');
    if (panel) {
        const isVisible = panel.style.display !== 'none';
        panel.style.display = isVisible ? 'none' : 'block';
        if (!isVisible) renderNotifications();
    }
}

// Close notification panel when clicking outside
document.addEventListener('click', function(e) {
    const panel = document.getElementById('notificationPanel');
    const btn = e.target.closest('.top-btn');
    if (panel && panel.style.display !== 'none' && !panel.contains(e.target) && !btn) {
        panel.style.display = 'none';
    }
});

// ==================== RECENT ACTIVITY ====================

function addActivity(type, title, detail) {
    if (!currentUser) return;
    const activities = JSON.parse(localStorage.getItem('re_activities_' + currentUser.email) || '[]');
    activities.unshift({
        type: type,
        title: title,
        detail: detail,
        date: new Date().toISOString()
    });
    if (activities.length > 20) activities.pop();
    localStorage.setItem('re_activities_' + currentUser.email, JSON.stringify(activities));
}

function renderRecentActivity() {
    const container = document.getElementById('recentActivityContainer');
    if (!container) return;

    if (!currentUser) {
        container.innerHTML = '<div style="text-align: center; padding: 20px; color: var(--cinza);"><p>Faça login para ver sua atividade</p></div>';
        return;
    }

    const activities = JSON.parse(localStorage.getItem('re_activities_' + currentUser.email) || '[]');

    if (activities.length === 0) {
        container.innerHTML = '<div style="text-align: center; padding: 20px; color: var(--cinza);"><i class="fas fa-history" style="font-size: 24px; margin-bottom: 8px; display: block;"></i><p style="font-size: 13px;">Nenhuma atividade registrada ainda</p></div>';
        return;
    }

    const icons = {
        login: 'fa-sign-in-alt',
        module_complete: 'fa-check-circle',
        trail_start: 'fa-route',
        password_change: 'fa-key',
        profile_update: 'fa-user-edit',
        search: 'fa-search'
    };

    const colors = {
        login: '#3b82f6',
        module_complete: '#10b981',
        trail_start: '#f59e0b',
        password_change: '#8b5cf6',
        profile_update: '#e89a1c',
        search: '#6b7280'
    };

    let html = '';
    activities.slice(0, 10).forEach(act => {
        const date = new Date(act.date).toLocaleDateString('pt-BR') + ' ' + new Date(act.date).toLocaleTimeString('pt-BR', {hour: '2-digit', minute:'2-digit'});
        html += '<div style="display: flex; align-items: center; gap: 12px; padding: 12px 16px; background: var(--cinza-claro); border-radius: 10px;">';
        html += '<div style="width: 36px; height: 36px; border-radius: 50%; background: ' + (colors[act.type] || '#6b7280') + '15; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">';
        html += '<i class="fas ' + (icons[act.type] || 'fa-circle') + '" style="font-size: 14px; color: ' + (colors[act.type] || '#6b7280') + ';"></i>';
        html += '</div>';
        html += '<div style="flex: 1; min-width: 0;">';
        html += '<div style="font-size: 13px; font-weight: 600; color: var(--azul-escuro);">' + escapeHtml(act.title) + '</div>';
        html += '<div style="font-size: 12px; color: var(--cinza);">' + escapeHtml(act.detail) + '</div>';
        html += '</div>';
        html += '<div style="font-size: 11px; color: var(--cinza); white-space: nowrap;">' + date + '</div>';
        html += '</div>';
    });

    container.innerHTML = html;
}

// ==================== ACHIEVEMENTS SYSTEM ====================

const ACHIEVEMENTS = {
    'first_module': { id: 'first_module', title: 'Primeiro Passo', desc: 'Complete seu primeiro módulo', icon: 'fa-shoe-prints', color: '#17a87d', condition: (stats) => stats.completed >= 1 },
    'five_modules': { id: 'five_modules', title: 'Cinco Estrelas', desc: 'Complete 5 módulos', icon: 'fa-star', color: '#f59e0b', condition: (stats) => stats.completed >= 5 },
    'ten_modules': { id: 'ten_modules', title: 'Décimo Módulo', desc: 'Complete 10 módulos', icon: 'fa-medal', color: '#8b5cf6', condition: (stats) => stats.completed >= 10 },
    'halfway': { id: 'halfway', title: 'Na Metade', desc: 'Complete 50% de uma trilha', icon: 'fa-flag', color: '#3b82f6', condition: (stats) => stats.maxTrailPct >= 50 },
    'trail_master': { id: 'trail_master', title: 'Mestre da Trilha', desc: 'Complete 100% de uma trilha', icon: 'fa-crown', color: '#e89a1c', condition: (stats) => stats.maxTrailPct >= 100 },
    'all_trails': { id: 'all_trails', title: 'Explorador', desc: 'Inicie todas as 4 trilhas', icon: 'fa-compass', color: '#dc2626', condition: (stats) => stats.trailsStarted >= 4 },
    'speed_runner': { id: 'speed_runner', title: 'Veloz', desc: 'Complete 3 módulos em um dia', icon: 'fa-bolt', color: '#f59e0b', condition: (stats) => stats.dailyCompletions >= 3 },
    'dedicated': { id: 'dedicated', title: 'Dedicado', desc: 'Acesse a plataforma 5 dias seguidos', icon: 'fa-fire', color: '#ef4444', condition: (stats) => stats.consecutiveDays >= 5 }
};

function checkAchievements() {
    if (!currentUser) return;

    const stats = calculateUserStats();
    const earned = JSON.parse(localStorage.getItem('re_achievements_' + currentUser.email) || '[]');
    let newEarned = false;

    for (const [key, ach] of Object.entries(ACHIEVEMENTS)) {
        if (!earned.includes(key) && ach.condition(stats)) {
            earned.push(key);
            newEarned = true;
            showNotification('🏆 Conquista desbloqueada: ' + ach.title + '!', 'success');
            addNotification('Conquista desbloqueada!', 'Você ganhou: ' + ach.title, 'success');
        }
    }

    if (newEarned) {
        localStorage.setItem('re_achievements_' + currentUser.email, JSON.stringify(earned));
    }

    renderAchievements(earned);
    return earned;
}

function calculateUserStats() {
    const allModules = [
        'mod-onboarding-1','mod-onboarding-2','mod-onboarding-3','mod-onboarding-4','mod-onboarding-5',
        'mod-onboarding-6','mod-onboarding-7','mod-onboarding-8','mod-onboarding-9',
        'mod-rel-1','mod-rel-2','mod-rel-3','mod-rel-4','mod-rel-5','mod-rel-6','mod-rel-7','mod-rel-8','mod-rel-9','mod-rel-10',
        'mod-astec-1','mod-astec-2','mod-astec-3','mod-astec-4','mod-astec-5',
        'mod-back-1','mod-back-2','mod-back-3','mod-back-4',
        'mod-rec-1','mod-rec-2','mod-rec-3','mod-rec-4','mod-rec-5',
        'mod-jur-1','mod-jur-2','mod-jur-3','mod-jur-4',
        'mod-comp-1','mod-comp-2','mod-comp-3','mod-comp-4','mod-comp-5'
    ];

    let completed = 0;
    let completionsToday = 0;
    const today = new Date().toDateString();

    allModules.forEach(mod => {
        if (userProgress[mod] && userProgress[mod].completed) {
            completed++;
            if (new Date(userProgress[mod].date).toDateString() === today) {
                completionsToday++;
            }
        }
    });

    const trails = {
        'onboarding': 9, 'relacionamento': 24, 'juridico': 4, 'compliance': 5
    };

    let maxTrailPct = 0;
    let trailsStarted = 0;

    for (const [trail, total] of Object.entries(trails)) {
        // Simple check - if any module in trail is completed, trail is started
        const trailModules = allModules.filter(m => m.includes(trail === 'onboarding' ? 'onboarding' : trail === 'relacionamento' ? 'rel-' : trail === 'juridico' ? 'jur-' : 'comp-'));
        const trailCompleted = trailModules.filter(m => userProgress[m] && userProgress[m].completed).length;
        if (trailCompleted > 0) trailsStarted++;
        const pct = Math.round((trailCompleted / total) * 100);
        if (pct > maxTrailPct) maxTrailPct = pct;
    }

    // Consecutive days (simplified - check last 5 login days)
    let consecutiveDays = 1;
    const loginHistory = JSON.parse(localStorage.getItem('re_logins_' + currentUser.email) || '[]');
    if (loginHistory.length > 0) {
        const sorted = loginHistory.map(d => new Date(d)).sort((a, b) => b - a);
        for (let i = 1; i < sorted.length; i++) {
            const diff = (sorted[i-1] - sorted[i]) / (1000 * 60 * 60 * 24);
            if (diff <= 1.5) consecutiveDays++;
            else break;
        }
    }

    return { completed, maxTrailPct, trailsStarted, dailyCompletions: completionsToday, consecutiveDays };
}

function renderAchievements(earned) {
    const container = document.getElementById('achievementsContainer');
    if (!container) return;

    let html = '';
    for (const [key, ach] of Object.entries(ACHIEVEMENTS)) {
        const isEarned = earned.includes(key);
        html += '<div style="display: flex; align-items: center; gap: 12px; padding: 16px; border-radius: 12px; background: ' + (isEarned ? ach.color + '15' : 'var(--cinza-claro)') + '; border: 2px solid ' + (isEarned ? ach.color : 'var(--borda)') + '; transition: var(--transition);">';
        html += '<div style="width: 44px; height: 44px; border-radius: 50%; background: ' + (isEarned ? ach.color : 'var(--borda)') + '; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">';
        html += '<i class="fas ' + ach.icon + '" style="font-size: 18px; color: ' + (isEarned ? 'white' : 'var(--cinza)') + ';"></i>';
        html += '</div>';
        html += '<div style="flex: 1;">';
        html += '<div style="font-size: 14px; font-weight: 700; color: ' + (isEarned ? ach.color : 'var(--cinza)') + ';">' + ach.title + '</div>';
        html += '<div style="font-size: 12px; color: ' + (isEarned ? 'var(--texto-leve)' : 'var(--cinza)') + ';">' + ach.desc + '</div>';
        html += '</div>';
        html += '<i class="fas ' + (isEarned ? 'fa-check-circle' : 'fa-lock') + '" style="font-size: 16px; color: ' + (isEarned ? ach.color : 'var(--cinza)') + ';"></i>';
        html += '</div>';
    }

    container.innerHTML = html;
}

function recordLogin() {
    if (!currentUser) return;
    const key = 're_logins_' + currentUser.email;
    const history = JSON.parse(localStorage.getItem(key) || '[]');
    const today = new Date().toISOString().split('T')[0];
    if (!history.includes(today)) {
        history.push(today);
        if (history.length > 30) history.shift();
        localStorage.setItem(key, JSON.stringify(history));
    }
}



// ==================== SUPABASE UPLOAD FUNCTIONS (REPLACEMENT) ====================
// Substitui as funções inline originais pelo módulo importado

async function uploadToSupabase(file, moduleId) {
    try {
        const result = await uploadFileToSupabase(file, moduleId)
        return result
    } catch(e) {
        console.error('Upload error:', e)
        showNotification('Erro no upload: ' + e.message, 'error')
        return { success: false, error: e.message }
    }
}

async function processUploads() {
    if (uploadQueue.length === 0) {
        showNotification('Nenhum arquivo na fila', 'warning')
        return
    }

    const moduleId = document.getElementById('materialModule')?.value || 'general'
    let successCount = 0

    for (const item of uploadQueue) {
        const el = document.getElementById(item.id)
        if (!el) continue

        const bar = el.querySelector('.file-progress-bar')
        const status = el.querySelector('.file-status')

        status.textContent = 'Enviando...'
        status.className = 'file-status pending'

        try {
            // Tentar upload para Supabase
            const result = await uploadFileToSupabase(item.file, moduleId)

            if (result.success) {
                // Salvar registro na tabela
                await saveFileRecord({
                    name: item.file.name,
                    url: result.url,
                    path: result.path,
                    type: item.file.type,
                    size: item.file.size,
                    module_id: moduleId,
                    uploaded_by: currentUser?.email || 'anonymous',
                    created_at: new Date().toISOString()
                })

                successCount++
                status.textContent = 'Concluído'
                status.className = 'file-status done'
                if (bar) bar.style.width = '100%'
            } else {
                status.textContent = 'Erro'
                status.className = 'file-status error'
            }
        } catch(e) {
            // Fallback: salvar localmente
            console.warn('Supabase upload failed, falling back to localStorage:', e)
            await simulateFileProgress(el)
            await saveFileToLocalStorage(item.file, moduleId)
            successCount++
            status.textContent = 'Salvo (local)'
            status.className = 'file-status done'
        }
    }

    showNotification(successCount + ' de ' + uploadQueue.length + ' arquivos enviados!', 'success')
    uploadQueue = []
}

function simulateFileProgress(el) {
    return new Promise((resolve) => {
        const bar = el.querySelector('.file-progress-bar')
        let progress = 0
        const interval = setInterval(() => {
            progress += Math.random() * 30
            if (progress >= 100) {
                progress = 100
                clearInterval(interval)
                resolve()
            } else {
                if (bar) bar.style.width = progress + '%'
            }
        }, 300)
    })
}

// ==================== LIST FILES FROM SUPABASE ====================
async function loadFilesFromSupabase(moduleId) {
    try {
        const files = moduleId ? await listFilesByModule(moduleId) : await listFileRecords()
        return files
    } catch(e) {
        console.error('Error loading files:', e)
        return []
    }
}

// ==================== DELETE FILE FROM SUPABASE ====================
async function deleteFileFromSupabase(path, recordId) {
    try {
        await deleteFileFromBucket(path)
        if (recordId) await deleteFileRecord(recordId)
        showNotification('Arquivo removido com sucesso', 'success')
        return true
    } catch(e) {
        console.error('Delete error:', e)
        showNotification('Erro ao remover arquivo', 'error')
        return false
    }
}

console.log('Relacionamento Ensina v8.0 - Sistema inicializado')
console.log('Supabase integrado:', !!supabase)
