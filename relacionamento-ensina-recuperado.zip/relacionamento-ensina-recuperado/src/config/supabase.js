// src/config/supabase.js
// Integração com Supabase - bucket "uploads" e tabela "arquivos"

import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Configurações
export const BUCKET_NAME = 'uploads'
export const TABLE_NAME = 'arquivos'

/**
 * Upload de arquivo para o bucket Supabase
 * @param {File} file - Arquivo a ser enviado
 * @param {string} moduleId - ID do módulo (pasta no bucket)
 * @returns {Promise<{success: boolean, url: string, path: string}>}
 */
export async function uploadFileToSupabase(file, moduleId = 'general') {
  const fileName = `${Date.now()}_${file.name}`
  const filePath = `${moduleId}/${fileName}`

  const { data, error } = await supabase
    .storage
    .from(BUCKET_NAME)
    .upload(filePath, file, {
      cacheControl: '3600',
      upsert: false
    })

  if (error) throw error

  const { data: { publicUrl } } = supabase
    .storage
    .from(BUCKET_NAME)
    .getPublicUrl(filePath)

  return { success: true, url: publicUrl, path: filePath }
}

/**
 * Lista registros da tabela "arquivos"
 * @returns {Promise<Array>}
 */
export async function listFileRecords() {
  const { data, error } = await supabase
    .from(TABLE_NAME)
    .select('*')
    .order('created_at', { ascending: false })

  if (error) throw error
  return data || []
}

/**
 * Salva registro na tabela "arquivos"
 * @param {Object} record - { name, url, type, size, module_id, uploaded_by }
 */
export async function saveFileRecord(record) {
  const { data, error } = await supabase
    .from(TABLE_NAME)
    .insert([record])

  if (error) throw error
  return data
}

/**
 * Deleta arquivo do bucket
 * @param {string} path - Caminho do arquivo no bucket
 */
export async function deleteFileFromBucket(path) {
  const { error } = await supabase
    .storage
    .from(BUCKET_NAME)
    .remove([path])

  if (error) throw error
  return { success: true }
}

/**
 * Deleta registro da tabela
 * @param {number} id - ID do registro
 */
export async function deleteFileRecord(id) {
  const { error } = await supabase
    .from(TABLE_NAME)
    .delete()
    .eq('id', id)

  if (error) throw error
  return { success: true }
}

/**
 * Lista arquivos de um módulo específico
 * @param {string} moduleId - ID do módulo
 */
export async function listFilesByModule(moduleId) {
  const { data, error } = await supabase
    .from(TABLE_NAME)
    .select('*')
    .eq('module_id', moduleId)
    .order('created_at', { ascending: false })

  if (error) throw error
  return data || []
}

console.log('[Supabase] Módulo carregado - bucket:', BUCKET_NAME, '| tabela:', TABLE_NAME)
