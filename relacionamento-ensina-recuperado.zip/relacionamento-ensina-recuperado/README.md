# Relacionamento Ensina - LMS Corporativo

## Canopus Construtora

Sistema de treinamento corporativo recuperado da versão publicada (v8.0).

## Estrutura do Projeto

```
├── index.html              # HTML principal (entry point)
├── src/
│   ├── main.js            # Entry point Vite
│   ├── config/
│   │   └── supabase.js    # Integração Supabase
│   ├── styles/
│   │   └── index.css      # Estilos CSS
│   └── scripts/
│       └── app.js         # Lógica JavaScript principal
├── public/                # Assets estáticos
├── package.json
├── vite.config.js
└── netlify.toml          # Configuração Netlify
```

## Configuração

1. Copie `.env.example` para `.env` e preencha suas credenciais Supabase:
```
VITE_SUPABASE_URL=https://seu-projeto.supabase.co
VITE_SUPABASE_ANON_KEY=sua-chave-anon
```

2. Instale as dependências:
```bash
npm install
```

3. Execute em desenvolvimento:
```bash
npm run dev
```

4. Build para produção:
```bash
npm run build
```

## Integração Supabase

O sistema está configurado para usar:
- **Bucket**: `uploads` (público)
- **Tabela**: `arquivos`
- **Variáveis de ambiente**: `VITE_SUPABASE_URL` e `VITE_SUPABASE_ANON_KEY`

## Deploy

### Netlify
1. Conecte o repositório GitHub ao Netlify
2. Configure as variáveis de ambiente no painel do Netlify
3. O build será automático via `netlify.toml`

### Variáveis de Ambiente no Netlify
```
VITE_SUPABASE_URL
VITE_SUPABASE_ANON_KEY
```

## Funcionalidades Preservadas

- ✅ Login de colaboradores (e-mail @canopus.com.br)
- ✅ Login administrativo
- ✅ 4 trilhas de aprendizagem (Onboarding, Relacionamento, Jurídico, Compliance)
- ✅ 42 módulos completos
- ✅ Progresso por trilha
- ✅ Certificados
- ✅ FAQ
- ✅ Painel administrativo
- ✅ Upload de arquivos (com integração Supabase)
- ✅ Dark mode
- ✅ Notificações
- ✅ Perfil do usuário

## Notas

Este projeto foi recuperado da versão publicada no Netlify.
Nenhuma funcionalidade foi alterada - apenas a estrutura foi reorganizada
para ser editável e compatível com GitHub/Vite.
